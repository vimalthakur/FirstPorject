<?php ob_start();
$message;
if (isset($_POST['signup'])) 
{
	include_once 'connection.php';
	$fname = $_POST['fullname'];
	$email = $_POST['email'];
	$password = $_POST['password']; 
	$c_password = $_POST['Confrom_Password'];
	
	if (filter_var($email, FILTER_VALIDATE_EMAIL)  && !empty($password) && !empty($c_password)) 
	{
		if ($password===$c_password) 
		{
			$password = md5($password);
			$query="insert into user_tbl(name,email,password) values('$fname','$email','$password')";
			if (mysqli_query($conn, $query)) 
			{
                $message = "<b class='text-success'> Registered sucessfully</b>";
			}
			else 
			{
				$message ="<b class='text-danger'>Somrhing went worng</b> ";
			}
		}
		else 
		{
			$message = "<b class='text-danger'>Password does not match</b>";
		}
	}
	else 
	{
		$message = "<b class='text-danger'>please ! Enter Vaild Detailes</b>";

	}
}

  ?>



<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
	 <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	  <link rel="stylesheet" type="text/css" href="css/signup.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Navbar</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto ">
      <li class="nav-item">
     <button type="button" class="btn btn-info" id=#>sign up</button>
      </li>
    </ul>
  </div>
</nav>
<!-- sign up forms -->
<form action="#" method="post" style="border:1px solid #ccc">
  <div class="container">
    <h1>Sign Up</h1>
    <!-- message alter Start -->
     <?php 
              if (!empty($message)) 
              {
                ?>
                 <div class="alert alert-success  alert-dismissible" role="alert">
                  <?php echo $message ?>
                  <span aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">&times;</span>
                 </div>

               <?php 
              }
              ?>
    <!-- message alter End -->

    <p>Please fill in this form to create an account.</p>
    <hr>

    <label for="inputfullname"><b>Full Name</b></label>
    <input type="text" name="fullname" placeholder="Enter Full Name" id="inputfullname" required>

    <label for="inputemail"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="inputemail" required>

    <label for="inputPassword"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" id="inputPassword" required>

    <label for="Confrom_Password"><b>Conform Password</b></label>
    <input type="password" placeholder="Conform Password" name="Confrom_Password" id="Confrom_Password" required>

    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>

    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn" name="signup">Sign Up</button>
    </div>
  </div>
</form>

</body>
</html>