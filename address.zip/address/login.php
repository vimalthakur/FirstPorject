<?php session_start();
ob_start();
if (!empty($_SESSION['user_id']) && !empty($_SESSION['email'])) 
  {
  	header("Location:index.php");
  }

  $msg='';
  if (isset($_POST['submit_login'])) 

 {
 
    if(!empty($_POST['name']) && !empty($_POST['password']))
    {
      $username=$_POST['name'];
      $password=$_POST['password'];

        include_once 'connection.php'; 
       $query1= "select * from user_tbl where email='$username'";
       $result1= mysqli_query($conn, $query1);
      if (mysqli_num_rows($result1) > 0) 
      {
        $row= mysqli_fetch_assoc($result1);
        $db_password=$row['password'];
        if (md5($password)===$db_password) 
        {
          $_SESSION['user_id'] = $row['user_id'];
          $_SESSION['email'] = $row['email'];
          header("Location:index.php");

        }
        else 
          $msg="<b class='text-danger'>Invalid Password</b>";
      } 
      else 
          $msg="<b class='text-danger'>Invalid Username</b>";
    }
    else 
      $msg="<b class='text-danger'>All fields are mendatory</b>";
 }


?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="utf-8">
	 <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet"id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body>
     
	<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
     <h3>Login</h3>
    </div>

    <!-- Login Form -->
    <form method="post">
       <p class="text-center">
         <?php 
             if(!empty($msg))
             {
               echo $msg;
             }
         ?>
        </p> 
        
      <input type="text" id="login" class="fadeIn second" name="name" placeholder="login" >
      <input type="text" id="password" class="fadeIn third" name="password" placeholder="password">
      <button  type="submit" class="btn btn-md px5 py2 btn-info" name="submit_login">Log In </button>
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="forgotpassword.php">Forgot Password?</a>
    </div>

  </div>
</div>

</body>
</html>