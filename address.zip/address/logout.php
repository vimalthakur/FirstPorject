<?php session_start();
ob_start();
if (!empty($_SESSION['user_id']) && !empty($_SESSION['email'])) 
  {
  	session_destroy();
  	header("Location:login.php");
  }
header("Location:login.php");
  ?>