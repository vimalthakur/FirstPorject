
<?php session_start();
include_once 'connection.php';


if (isset($_POST["add_address"])) 
{
	
	$address = $_POST["address"];
	$query= "insert into address_tbl(address) values('$address')";
	if (mysqli_query($conn,$query)) 
	{
		$m= "address inserted";
		$_SESSION['m']=$m;
		header("Location:index.php");
	}
	else 
	{
		 $m= "something went wrong";
		 $_SESSION['m']=$m;
		 header("Location:index.php");
	}

	
}
elseif (isset($_POST["delete_address_id"])) 
{
	
	$id = $_POST["delete_address_id"];
	$query= " delete from address_tbl where id= $id";
	if (mysqli_query($conn,$query)) 
	{
		$m= "Address deleted";
		$_SESSION['m']=$m;
		header("Location:index.php");
	}
	else 
	{
		 
		$m= "Address not deleted";
		$_SESSION['m']=$m;
		header("Location:index.php");
	}
	
}
elseif (isset($_POST["edit_address"]))
{
	$id = $_POST['editid'];
	$add = $_POST["editaddress"];
	$query = "update address_tbl set address = '$add' where id=$id";
	if (mysqli_query($conn, $query)) 
	{
		$m= "Address Updated";
		$_SESSION['m']=$m;
		header("location:index.php");
	}
	else 
	{
        $m= "Address not Updated";
		$_SESSION['m']=$m;
		header("location:index.php");
	}
}

?>