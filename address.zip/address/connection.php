<?php 
$conn=mysqli_connect('localhost', 'root','' , 'address');
if (!$conn) {
 	# code...
 	die("connection failed".mysqli_connect_error($conn));
 } 
 ?>