<?php session_start();
if (empty($_SESSION['user_id'])|| empty($_SESSION['email'])) 
  {
  	header("Location:login.php");
  }
?>


<!DOCTYPE html>
<html>
<head>
	<?php include_once 'connection.php'; ?>
	<title>Address from</title>
    <?php include_once 'header.php'; ?>
      <title>Bootstrap Example</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</head>
<body>
	<!-- modal start Address -->
	<div class="modal" id="addnew">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title text-center">Addnew Address</h4>
          <button type="button" class="close d-inline" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">       
			    <form action="process.php" method="post">
  				<fieldset class="form-group">
    				<label for="address">Address</label>
      				<input type="text" class="form-control" id="address" 
      				  name="address">
  				</fieldset>
  				<button type="submit" class="btn btn-primary" name="add_address">Submit
  				</button>
		   </form>        	

        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>

	<!-- modal colse Address -->


	


	<div class="container">
	  <h2 class="text-center">Simple Basic Address Table</h2>     
	      <?php 
             if(isset($_SESSION['m']))
             {
             	$m =$_SESSION['m'];
               echo "<p class='text-success text-center font-weight-bold'>$m</p>";
               session_unset('m');
             }
	      ?>     
		  <table class="table table-striped table-hover">
		    <thead>
		      <tr>
		        <th>sr.no</th>
		        <th>Address</th>
		        <th>Status</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php
		    	$q1="select *from address_tbl";
		    	$res1=mysqli_query($conn,$q1);
		    	if (mysqli_num_rows($res1) > 0) 
		    	{
		    		$sron=1;
		    		while ($row = mysqli_fetch_assoc($res1)) 
		    		 {
		    		 	$id=$row['id'];
		    		 	$add=$row['address'];
		    	?>
		      <tr>
		        <td> <?php echo $sron ?> </td>
		        <td> <?php echo $row['address']; ?> </td>
		        <td>
		        	<button class="btn btn-info" data-target="#updateform<?php echo $id?>"  data-toggle="modal">update   </button>
		        	<!-- modal start updated -->
					<div class="modal" id="updateform<?php echo $id?>">
					    <div class="modal-dialog">
					      <div class="modal-content">

					        <!-- Modal Header -->
					        <div class="modal-header">
					          <h4 class="modal-title text-center">Update Address</h4>
					          <button type="button" class="close d-inline" data-dismiss="modal">&times;</button>
					        </div>
					        
					        <!-- Modal body -->
					        <div class="modal-body">       
								    <form action="process.php" method="post">
					  				<fieldset class="form-group">
					    				<label for="address">Address</label>

					    				<input type="hidden" name="editid" value="<?php echo $id?>">
					      				<input type="text" class="form-control" 
					      				  name="editaddress" value="<?php echo $add?>">
					  				</fieldset>
					  				<button type="submit" class="btn btn-primary" name="edit_address">Submit
					  				</button>
							   </form>        	

					        </div>
					        
					        <!-- Modal footer -->
					        <div class="modal-footer">
					          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
					        </div>
					        
					      </div>
					    </div>
					  </div>


	<!-- modal start updated -->

		        	<form action="process.php" method="post">
		        		<input type="hidden" name="delete_address_id" value="<?php echo $id ?>">

		        		<button class="btn btn-danger" type="submit">delete</button>
		        		
		        	</form>
		        </td>
		      </tr>
		      <?php
		      $sron++;
		            }
		        }
		        ?>
		    </tbody>
		  </table>
	</div>

</body>
<?php include_once 'footer.php'; ?>
</html>