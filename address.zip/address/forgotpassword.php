<?php session_start();
ob_start();
	if (!empty($_SESSION['user_id']) && !empty($_SESSION['email'])) 
	{
		header('Location:index.php');
	}
	$msg='';
		if (isset($_POST['update'])) 
		{
		 	if (!empty($_POST['email'])) 
		 	{
			 	include_once 'connection.php'; 	
				$email=$_POST['email'];
				$q1= "select * from user_tbl where email='$email'";

				$res1= mysqli_query($conn, $q1);
				if (mysqli_num_rows($res1) > 0) 
				{
				  $row = mysqli_fetch_assoc($res1);  
			      $email=$row['email'];
			      $user_id=$row['email'];
			      	$email=$row['email'];
			      	$password = $_POST['password'];
			      	$c_password = $_POST['c_password'];
			      	if ($password == $c_password) 
			      	{
			      		$password= md5($password);
						$query= "Update user_tbl SET  password='$password' where email = '$email'";
						if(mysqli_query($conn, $query))
							header("Location:index.php");

						else $msg="<b class='text-danger'>password does not match</b>";
			        }
			    }
					   
				    else 
					$msg="<b class='text-danger'>NO Data Found!!</b>";
		    }
	    }

?>

<!DOCTYPE html>
<html>
<head>
	<title>Forgot password</title>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
	<div class="container">
        <div class="row justify-content-center align-items-center" style="height:100vh">
            <div class="col-4">
                <div class="card">
                    <div class="card-body">
                        <form  autocomplete="off" method="post">
                        	<p class="text-center">
					         <?php 
					             if(!empty($msg))
					             {
					               echo $msg;
					             }
					         ?>
					        </p>
                            <div class="form-group">
                            	<label>Email</label>
                                <input type="email" class="form-control" name="email" placeholder="Enter Your email" >
                            </div>
                               <div class="form-group">
                            	<label> Password</label>
                                <input type="password" class="form-control" name="password" placeholder="Enter Password">
                            </div>
                            <div class="form-group">
                            	<label>Create Your New Password</label>
                                <input type="password" class="form-control" name="c_password" placeholder="Enter Password">
                            </div>
                            <button type="submit" id="forgotpassword" name="update" class="btn btn-primary ">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>